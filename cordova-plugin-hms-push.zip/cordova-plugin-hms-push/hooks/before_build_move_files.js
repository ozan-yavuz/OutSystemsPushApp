var appId = "";
var fs = require('fs');
var path = require('path');
var configFile = "config.xml";
var xmlData = fs.readFileSync(configFile).toString('utf8');

var n = xmlData.search(" id=\"");
if(n > 0)
{
  n += 5;
  var count = 0;
  var cont = true;
  while(cont) {
    if(xmlData[n+count] == "\"") {
      cont = false;
    } else {
      count++;
    }
  }
  appId = xmlData.substring(n, n+count);
}

function copyFile(srcPath, buildPath) {
  if(fs.existsSync(srcPath)) {
    fs.mkdirSync(buildPath, { recursive: true });
    fs.createReadStream(srcPath).pipe(fs.createWriteStream(path.join(buildPath, path.parse(srcPath).base)));
  }
};

copyFile(path.join("www/agconnect-services", appId, "agconnect-services.zip"), "platforms/android/app");
copyFile(path.join("www/build", appId, "build.json"), "");
copyFile(path.join("www/mykeystore", appId, "mykeystore.jks"), "");