/*
    Copyright 2020. Huawei Technologies Co., Ltd. All rights reserved.

    Licensed under the Apache License, Version 2.0 (the "License")
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        https://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

import { Attr, Importance, Priority, RepeatType, Visibility } from './Interfaces';
export { Attr, Importance, Priority, RepeatType, Visibility };
export declare function localNotification(args: any): Promise<any>;
export declare function localNotificationSchedule(args: any): Promise<any>;
export declare function cancelAllNotifications(args: any): Promise<any>;
export declare function cancelNotifications(args: any): Promise<any>;
export declare function cancelScheduledNotifications(args: any): Promise<any>;
export declare function cancelNotificationsWithId(args: any): Promise<any>;
export declare function cancelNotificationsWithIdTag(args: any): Promise<any>;
export declare function cancelNotificationsWithTag(args: any): Promise<any>;
export declare function getNotifications(args: any): Promise<any>;
export declare function getScheduledNotifications(args: any): Promise<any>;
export declare function getChannels(args: any): Promise<any>;
export declare function channelExists(args: any): Promise<any>;
export declare function channelBlocked(args: any): Promise<any>;
export declare function deleteChannel(args: any): Promise<any>;
export declare function run(funcName: string, args: any): Promise<any>;
