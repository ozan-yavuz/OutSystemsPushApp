"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Visibility = exports.RepeatType = exports.Priority = exports.Importance = exports.Attr = void 0;
/*
    Copyright 2020. Huawei Technologies Co., Ltd. All rights reserved.

    Licensed under the Apache License, Version 2.0 (the "License")
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        https://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

var Attr;
(function (Attr) {
  Attr["id"] = "id";
  Attr["message"] = "message";
  Attr["fireDate"] = "fireDate";
  Attr["title"] = "title";
  Attr["ticker"] = "ticker";
  Attr["showWhen"] = "showWhen";
  Attr["autoCancel"] = "autoCancel";
  Attr["largeIcon"] = "largeIcon";
  Attr["largeIconUrl"] = "largeIconUrl";
  Attr["smallIcon"] = "smallIcon";
  Attr["bigText"] = "bigText";
  Attr["subText"] = "subText";
  Attr["bigPictureUrl"] = "bigPictureUrl";
  Attr["shortcutId"] = "shortcutId";
  Attr["number"] = "number";
  Attr["channelId"] = "channelId";
  Attr["channelName"] = "channelName";
  Attr["channelDescription"] = "channelDescription";
  Attr["color"] = "color";
  Attr["group"] = "group";
  Attr["groupSummary"] = "groupSummary";
  Attr["playSound"] = "playSound";
  Attr["soundName"] = "soundName";
  Attr["vibrate"] = "vibrate";
  Attr["vibrateDuration"] = "vibrateDuration";
  Attr["actions"] = "actions";
  Attr["invokeApp"] = "invokeApp";
  Attr["tag"] = "tag";
  Attr["repeatType"] = "repeatType";
  Attr["repeatTime"] = "repeatTime";
  Attr["ongoing"] = "ongoing";
  Attr["allowWhileIdle"] = "allowWhileIdle";
  Attr["dontNotifyInForeground"] = "dontNotifyInForeground";
  Attr["priority"] = "priority";
  Attr["importance"] = "importance";
  Attr["visibility"] = "visibility";
})((Attr = exports.Attr || (exports.Attr = {})));
var Importance;
(function (Importance) {
  Importance["MAX"] = "max";
  Importance["HIGH"] = "high";
  Importance["DEFAULT"] = "default";
  Importance["LOW"] = "low";
  Importance["MIN"] = "min";
  Importance["NONE"] = "none";
  Importance["UNSPECIFIED"] = "unspecified";
})((Importance = exports.Importance || (exports.Importance = {})));
var Priority;
(function (Priority) {
  Priority["MAX"] = "max";
  Priority["HIGH"] = "high";
  Priority["DEFAULT"] = "default";
  Priority["LOW"] = "low";
  Priority["MIN"] = "min";
})((Priority = exports.Priority || (exports.Priority = {})));
var RepeatType;
(function (RepeatType) {
  RepeatType["HOUR"] = "hour";
  RepeatType["MINUTE"] = "minute";
  RepeatType["DAY"] = "day";
  RepeatType["WEEK"] = "week";
  RepeatType["CUSTOM_TIME"] = "custom_time";
})((RepeatType = exports.RepeatType || (exports.RepeatType = {})));
var Visibility;
(function (Visibility) {
  Visibility["PUBLIC"] = "public";
  Visibility["SECRET"] = "secret";
  Visibility["PRIVATE"] = "private";
})((Visibility = exports.Visibility || (exports.Visibility = {})));
//# sourceMappingURL=Interfaces.js.map
